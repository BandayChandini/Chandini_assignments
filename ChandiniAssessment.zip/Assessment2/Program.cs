﻿using static System.Reflection.Metadata.BlobBuilder;
using System.ComponentModel;
using System.Text;
using System;
using System.IO;
using System.Xml.Linq;

namespace Assessment2
{
 /*   Write a menu driven program to implement a solution to manage Books of a Library with following
options:
1. Create Book
a.Book has following details: bookId, bookName, price , author and publisher
2. Update Book details
a.This option should allow user to update either one of following details of the book like price and other
details
3. Display following book details.
a.Display book details based on bookId.
b.Display book details based on bookNae.
c.Display all books based on author.
d.Display all books based on author and publisher.
e.Display all books details.

Minimum Expectations
• Coding standards and best practices should be followed
• Implement arrays or list whenever required
• Should use Repository Pattern(Interface and class) for CRUD operations
• Implement exceptions Handling for all the methods defined in Repository Class*/

    interface BookRepository {
        List<Book> GetAllBooks();
        Book GetBookById(int bookId);
        Book GetBookByName(string name);
        Book GetAuthor(string author);
        Book GetBookByAuthorandPublisher(string author,string publisher);
        void AddBook(Book book);

        void RemoveBook(int bookId);
        void Updatename(Book book);
        void Updateprice(Book book);
    }
    class Books : BookRepository
    {
        
        List<Book> list = new List<Book>();
        public void AddBook(Book book)
        {
            list.Add(book);

        }

        public List<Book> GetAllBooks()
        {
            return list;
        }
        public Book GetBookByName(string name)
        {
            foreach (Book book in list)
            {
                if (book.bookname == name) return book;
            }
            return null;
        }
        public Book GetAuthor(string author)
        {
            foreach (Book book in list)
            {
                if (book.author == author) return book;
            }
            return null;

        }
        public Book GetBookByAuthorandPublisher(string author, string publisher)
        {
            foreach (Book book in list)
            {
                if (book.author == author&& book.publisher==publisher) return book;
            }
            return null;

        }
        public Book GetBookById(int bookId)
        {

            foreach (Book item in list)
            {
                if (item.bookId == bookId) return item;

            }
            return null;

        }

        public void RemoveBook(int bookId)
        {
            Book book = null;
            foreach (Book item in list)
            {
                if (item.bookId == bookId)
                {
                    book = item;
                    break;
                }

            }
            if (book != null)
                list.Remove(book);
        }

        public void Updateprice(Book book)
        {
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].bookId == book.bookId)
                {
                    list[i].price = book.price;
                }
            }
        } 

        public void Updatename(Book book)
        {
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].bookId == book.bookId)
                {
                    list[i].bookname = book.bookname; 
                }
            }
        }
    }

        internal class Program
    {
        static void Main(string[] args)
        {
            
            BookRepository repository = null;
            try
            {
                do
                {
                    Console.WriteLine("1.Add\n2.GetById\n3.GetAllbooks\n4.Remove book\n5.update name\n6.update price\n7.bookbyname\n8.bookauthor\n9.exit");
                    Console.WriteLine("choose an option: ");
                    int op=int.Parse(Console.ReadLine());
                    switch (op)
                    {
                        case 1: 
                            {
                                Book listss = new Book();
                                Console.WriteLine("Enter the id of the book");
                                listss.bookId = int.Parse(Console.ReadLine());
                                Console.WriteLine("Enter name of the book");
                                listss.bookname = Console.ReadLine();
                                Console.WriteLine("Enter price of the book");
                                listss.price = int.Parse(Console.ReadLine());
                                repository.AddBook(listss);
                            }
                            break;
                        case 2: 
                            {
                                Console.WriteLine("Enter id of the book");
                                int id = int.Parse(Console.ReadLine());
                                Book listss = repository.GetBookById(id);
                                if (listss != null)
                                {
                                    Console.WriteLine(listss.ToString());
                                }
                                else
                                    Console.WriteLine("Invalid bookid");
                            }
                            break;
                        case 3: 
                            {
                                List<Book> books = repository.GetAllBooks();
                                if (books.Count > 0)
                                {
                                    foreach (var item in books)
                                    {
                                        Console.WriteLine(item);
                                    }
                                }
                                else
                                    Console.WriteLine("List is Empty");
                            }
                            break;
                        case 4:
                            {
                                Console.WriteLine("Enter Book Id");
                                int id = int.Parse(Console.ReadLine());
                                repository.RemoveBook(id);
                            }
                            break;
                        case 5: 
                            {
                                Book listss = new Book();
                                listss.bookId = int.Parse(Console.ReadLine());
                                Console.WriteLine("Enter name of the book");
                                listss.bookname = Console.ReadLine();
                                repository.Updatename(listss);
                            }
                            break;
                        case 6:
                            {
                                Book listss = new Book();
                                listss.bookId = int.Parse(Console.ReadLine());
                                Console.WriteLine("Enter price of the book");
                                listss.price = int.Parse(Console.ReadLine());
                                repository.Updateprice(listss);
                            }
                            break;
                        case 7:
                            Console.WriteLine("Enter id of the book");
                            string name = Console.ReadLine();
                            Book list = repository.GetBookByName(name);
                            if (list != null)
                            {
                                Console.WriteLine(list.ToString());
                            }
                            else { 
                                Console.WriteLine("Invalid bookname");
                            }break;
                        case 8:
                            Console.WriteLine("Enter name of the book");
                            string author = Console.ReadLine();
                            Book lists = repository.GetBookByName(author);
                            if (lists != null)
                            {
                                Console.WriteLine(lists.ToString());
                            }
                            else
                            {
                                Console.WriteLine("Invalid bookauthor");
                            }
                            break;
                        

                        case 9:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Invalid Option");
                            break;
                    }

                } while (true);

            }catch(FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            
        }
    }
}
