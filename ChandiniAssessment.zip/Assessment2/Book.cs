﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Reflection.Metadata.BlobBuilder;

namespace Assessment2
{
    /*  Write a menu driven program to implement a solution to manage Books of a Library with following
  options:
  1. Create Book
  a.Book has following details: bookId, bookName, price , author and publisher
  2. Update Book details
  a.This option should allow user to update either one of following details of the book like price and other
  details
  3. Display following book details.
  a.Display book details based on bookId.
  b.Display book details based on bookNae.
  c.Display all books based on author.
  d.Display all books based on author and publisher.
  e.Display all books details.

  Minimum Expectations
  • Coding standards and best practices should be followed
  • Implement arrays or list whenever required
  • Should use Repository Pattern(Interface and class) for CRUD operations
  • Implement exceptions Handling for all the methods defined in Repository Class*/
    internal class Book
    {
        
        public long bookId { get; set; }
        
        public string bookname { get; set; }
        public double price {  get; set; }
        public string author { get; set; }
        public string publisher { get; set; }
        
        public void Details()
        {
            Console.WriteLine($"bookId: {bookId},bookname:{bookname},price:{price},author:{author},publisher:{publisher}");
        }
    
    }
    class Demo
    {
        Book obj= new Book();
        List<Book> books = new List<Book>()
        {
            new Book{bookId=10,bookname="abc",price=3500,author="xyz",publisher="pqr"},
            new Book{bookId=10,bookname="abc",price=3500,author="xyz",publisher="pqr"},
            new Book{bookId=10,bookname="abc",price=3500,author="xyz",publisher="pqr"},
            new Book{bookId=10,bookname="abc",price=3500,author="xyz",publisher="pqr"},
            new Book{bookId=10,bookname="abc",price=3500,author="xyz",publisher="pqr"},
            new Book{bookId=10,bookname="abc",price=3500,author="xyz",publisher="pqr"},

        };
        

    }
}
